package seleniumprojects;

public class statement extends utills{

	String from="//input[@name='fdate']";
	String tdate="//input[@name='tdate']";
	
	public void cusstatement()
	{
		click("//a[@href='CustomisedStatementInput.php']");
		click("//input[@name='accountno']");
		typetext(from, "02/20/2022");
		typetext(tdate, "22/04/2022");
		click("//input[@name='res']");
				
	}
	
}
