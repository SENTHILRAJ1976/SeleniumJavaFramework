package seleniumprojects;

public class addnewcustomerpage extends utills{
	
	String customername= "//input[@name='name']";
	String DOB = "//input[@name='dob']";
	String address="/textarea[@name='addr']";
	String city="//input[@name='city']";
	String state="//input[@name='state']";
	String pincode="//input[@name='pinno']";
	String email="//input[@name='emailid']";
	

	public void newcustomer()
	{
		click("//a[@href='addcustomerpage.php']");
		
		typetext(customername, "Arumugaperumal");
		
		click("(//input[@type='radio'])[2]");
		
		click("(//input[@type='radio'])[1]");
		
		typetext(DOB, "01/10/1900");
		
		typetext(address, "Maximizing a browser window at first also provides better visibility to the QAs.");
		
		typetext(city, "Madurai");
		
		typetext(state, "TamilNadu");
		
		typetext(pincode, "600041");
		
		typetext(email, "aaru.victory@gmail.com");
		
		click("//input[@name='res']");
		
	}
	
}