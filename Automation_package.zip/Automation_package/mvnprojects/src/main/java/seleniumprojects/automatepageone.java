package seleniumprojects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class automatepageone {

	public static WebDriver driver;
	
	public static ExtentHtmlReporter html;
	public static ExtentReports Report;
	public static ExtentTest test;
	
		
	public static void launchbrowser()
	{
		WebDriverManager.chromedriver().setup();
		
//		ChromeOptions option= new ChromeOptions();
//		option.addArguments("start--maximized");
//		option.addArguments("--disable-extensions");		

		driver = new ChromeDriver();
		
	}
	
	
	public static void openurl(String url)
	{
		driver.get(url);
	}
	
	public static void gettitle()
	{
		driver.getTitle();
				
	}
	
	public static void typetext(String locaters, String value)
	{
		driver.findElement(By.xpath(locaters)).sendKeys(value);
		
	}

	public static void click(String locaters)
	{
		driver.findElement(By.xpath(locaters)).click();
		
	}
	
	public static void dropdownselection(String locaters, String value)
	{
		Select select=new Select(driver.findElement(By.xpath(locaters)));
		select.selectByVisibleText(value);
		
	}
	
	public static void refresh()
	{
		driver.navigate().refresh();
		
	}
	
	public static void forward() 
	{
		driver.navigate().forward();
		
	}
	
	public static void backward()
	{
		driver.navigate().back();
		
	}
	
	public static void impwait(int wiattime)
	{
		driver.manage().timeouts().implicitlyWait(wiattime, TimeUnit.SECONDS);
		
	}
	
	public static void clickUsingJavascipt (String locators, String value) {
		
		WebElement createac = driver.findElement(By.xpath("//div[3]/div/ul/li[5]/a[contains(text(), 'New Account')]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", createac);
		
	}
	
	public static void extentreportinitiate() {
		String Userdirectory = System.getProperty("user.dir");
		html = new ExtentHtmlReporter(Userdirectory + "\\TestResult.html");
		Report = new ExtentReports();
		Report.attachReporter(html);
	}

	public static void extentreportfinisher() {
		Report.flush();
	}
	
	public static void exit()
	{
		driver.close();
		
	}
}