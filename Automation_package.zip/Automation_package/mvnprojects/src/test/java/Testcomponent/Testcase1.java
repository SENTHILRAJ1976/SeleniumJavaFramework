package Testcomponent;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import basecomponent.baseclass;
import seleniumprojects.addnewcustomerpage;
import seleniumprojects.loginscreen;
import seleniumprojects.logoutpage;
import seleniumprojects.newaccount;
import seleniumprojects.statement;
import seleniumprojects.utills;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Testcase1 extends baseclass{
	
	@Test(priority = 1)
	  public void login() {
		try {
			
			test=Report.createTest("Verify Login Page");
			loginscreen log= new loginscreen();
			log.login();
			test.log(Status.PASS, "Login Sucessfully");
						
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail();
			test.log(Status.FAIL,"Test case failed due to: "+e.getMessage());		
		}	  
	  }

	  @Test(priority = 2)
	  public void addnewcustomer() throws InterruptedException {
			try {
				
				Thread.sleep(5000);
			  	test=Report.createTest("Verify Add Customer Page");
				loginscreen log= new loginscreen();
				log.login();
				
				addnewcustomerpage addcustomer=new addnewcustomerpage();
				addcustomer.newcustomer();
				test.log(Status.PASS, "Addnewcustomer page open successfully");
				
			} catch (Exception e) {
				// TODO: handle exception
				Assert.fail();
				test.log(Status.FAIL, "Test Case Failed due to"+e.getMessage());
				
			}				  
	  }
	  
	  
	  @Test(priority = 3)
	  public void newaccount() throws InterruptedException {
		 try {
			 test=Report.createTest("Verify New Account Page");
			 Thread.sleep(5000);
			  loginscreen log= new loginscreen();
				log.login();
				
				newaccount new_account=new newaccount();
				new_account.newacc();
				test.log(Status.PASS, "Add new account page open successfull");
			 
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail();
			test.log(Status.FAIL, "Test Case Failed due to"+e.getMessage());
			
		}	  
	  }
	  
	  @Test(priority = 4)
	  public void mini_statement() throws InterruptedException {
		 
		try {
			test=Report.createTest("Verify Mini Statement");
			Thread.sleep(5000);  
			  
			loginscreen log= new loginscreen();
			log.login();
		  
			statement ministatement = new statement();
			ministatement.cusstatement();
			test.log(Status.PASS, "Ministatement Open successfully");
			
			
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail();
			test.log(Status.FAIL, "Test Case Failed due to"+e.getMessage());
			
		}  		
	  }
	  	  
	  @Test(priority = 5)
	  public void logout() throws InterruptedException {
		  try {
			  test=Report.createTest("Verify Logout");
			  Thread.sleep(3000);
			  loginscreen log= new loginscreen();
				log.login();
			  
			  logoutpage log_out = new logoutpage();
				log_out.logout();
				test.log(Status.PASS, "Logout Successfully");
					  
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail();
			test.log(Status.FAIL, "Test Case Failed due to"+e.getMessage());
		}		  	  
	  }
}