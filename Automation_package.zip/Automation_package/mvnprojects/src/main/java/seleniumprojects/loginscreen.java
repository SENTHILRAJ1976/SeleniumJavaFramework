package seleniumprojects;

public class loginscreen extends utills{
	
	String username = "//input[@name='uid']";
	String password = "//input[@name='password']";
	String login = "//input[@name='btnLogin']";
	
	public void login()
	{		
		typetext(username, "mngr402106");
		typetext(password, "UveqezE");			
		click(login);
				
	}

}