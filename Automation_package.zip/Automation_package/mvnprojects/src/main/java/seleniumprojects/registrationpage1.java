package seleniumprojects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class registrationpage1 {

	static WebDriver driver = new ChromeDriver();
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		//Launch chrome driver
			
		
		ChromeOptions option= new ChromeOptions();
		option.addArguments("start--maximized");
		option.addArguments("--disable-extensions");
		
		driver.get("http://demo.automationtesting.in/Register.html");
		
		
		
//		WebDriverManager.safaridriver().setup();
//		
//		//Launch safari driver
//		WebDriver safaridriver = new SafariDriver();
//		safaridriver.get("http://demo.automationtesting.in/Register.html");
//
//		
//		driver.close();
//		safaridriver.close();
		
		
		WebElement firstname =driver.findElement(By.xpath("//input[@placeholder='First Name']"));
				   firstname.sendKeys("Arumugaperumal");
		
		WebElement lastname = driver.findElement(By.xpath("//input[@placeholder='Last Name']"));
				   lastname.sendKeys("Duraipandi");
		
		WebElement address = driver.findElement(By.xpath("//textarea[@ng-model='Adress']"));
				   address.sendKeys("Thiruvanmiyur, Chennai 600041");
		
		WebElement email = driver.findElement(By.xpath("//input[@ng-model='EmailAdress']"));
				   email.sendKeys("automationtester@yahoo.com");
		
		WebElement pnumber = driver.findElement(By.xpath("//input[@ng-model='Phone']"));
				   pnumber.sendKeys("0909090909");
		
		WebElement rbutton = driver.findElement(By.xpath("//input[@value='Male']"));
				   rbutton.click();
		
		WebElement checkbox= driver.findElement(By.xpath("//input[@value='Cricket']"));
				   checkbox.click();
		
				   checkbox=driver.findElement(By.xpath("//input[@value='Movies']"));
		           checkbox.click();
		
		WebElement lng = driver.findElement(By.xpath("//div[@id='msdd']"));
				   
					lng.click();
					
		lng = driver.findElement(By.xpath("(//a[@class='ui-corner-all'])[1]"));
					lng.click();

		//Array list			
					
//		List<String>lng1=new ArrayList<String>();
//		lng1.add("English");
//		
//		List<String>lng2=new ArrayList<String>();
//		List<WebElement> languages=driver.findElements(By.xpath("//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']//li//a"));
//		
//		for (int i = 1; i < languages.size(); i++) {
//			
//			String xpathform= "(//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']//li//a)["+i+"]";
//			String output=driver.findElement(By.xpath(xpathform)).getAttribute("innerText");
//			lng1.add(output);
//						
//		}
//			System.out.println(lng1);	
			
			
			//	gettext();
			//	getAttribute("innerText");
			//	getAttribute("innerHTML");
			
			
		
		WebElement skils = driver.findElement(By.xpath("//label[text()='Skills']"));
					skils.click();
		
		Select dropdown = new Select(driver.findElement(By.xpath("//select[@id='Skills']")));
		
		dropdown.selectByVisibleText("Java");
		
		Select dob = new Select(driver.findElement(By.xpath("//select[@id='yearbox']")));
		dob.selectByVisibleText("1989");
		
		
		WebElement fstpassword = driver.findElement(By.xpath("//input[@id='firstpassword']"));
				fstpassword.sendKeys("Test@12345");
				
		WebElement sndpassword = driver.findElement(By.xpath("//input[@id='secondpassword']"));
				sndpassword.sendKeys("Test@12345");
		
		
		WebElement fileupload = driver.findElement(By.xpath("//input[@onchange='uploadimg()']")); 
					fileupload.sendKeys("/Users/parthasarathy/Downloads/Aadhar.jpeg");
		
		WebElement submit = driver.findElement(By.xpath("//button[@name='signup']"));
		           submit.click();
		
	//	driver.quit();
		
	}
	

}
