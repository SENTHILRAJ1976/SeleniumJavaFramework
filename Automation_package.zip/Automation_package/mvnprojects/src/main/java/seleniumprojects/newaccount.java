package seleniumprojects;

public class newaccount extends utills {
	
	String customerid="//input[@name='cusid']";
	String selectaccount="//select[@name='selaccount']";
	String deposit="//input[@name='inideposit']";
	String new_acc="//div[3]/div/ul/li[5]/a[contains(text(),'New Account')]";
	
	
	public void newacc ()
	{
		clickUsingJavascipt("//div[3]/div/ul/li[5]/a[contains(text(),'New Account')]", "New Account");
		typetext(customerid, "0123456");
		dropdownselection(selectaccount, "current");
		typetext(deposit, "100000000");
		click("//input[@name='button2']");		
	}

}