package seleniumprojects;

public class deleteaccount extends utills{

	String accnumber = "//input[@name='accountno']";
	String submit = "//input[@value='Reset']";
	
	public void delete() 
	{		
		click("//a[@href='deleteAccountInput.php']");
		typetext(accnumber, "091290206");
		click(submit);
		
		
	}

}
