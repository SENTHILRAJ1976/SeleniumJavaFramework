package basecomponent;

import seleniumprojects.utills;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class baseclass extends utills{

  
  
  @BeforeMethod
  public void beforeMethod() {
	  launchbrowser();	
	  openurl("https://demo.guru99.com/V1/index.php");	  
	  
  }
  
  
  @AfterMethod
  public void afterMethod() {
	  
	  exit();
  
  }

  
  @BeforeSuite
  public void beforeSuite() {
	  extentreportinitiate();
  
  }

  
  @AfterSuite
  public void afterSuite() {
	  extentreportfinisher(); 
	  
  }

}