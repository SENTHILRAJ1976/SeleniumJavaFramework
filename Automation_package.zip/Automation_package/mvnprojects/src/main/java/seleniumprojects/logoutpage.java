package seleniumprojects;

public class logoutpage extends utills{

	public void logout()
	{
		click("//a[@href='Logout.php']");
		
	}
	
}
