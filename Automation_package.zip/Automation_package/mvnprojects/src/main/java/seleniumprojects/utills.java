package seleniumprojects;

public class utills extends automatepageone{
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	
	launchbrowser();	
		
	openurl("https://demo.guru99.com/V1/index.php");
		
	loginscreen log= new loginscreen();
	log.login();
	
	addnewcustomerpage addcustomer=new addnewcustomerpage();
	addcustomer.newcustomer();
	
	newaccount new_account=new newaccount();
	new_account.newacc();
	
	statement ministatement = new statement();
	ministatement.cusstatement();
	
	logoutpage log_out = new logoutpage();
	log_out.logout();
	
	deleteaccount del=new deleteaccount();
	del.delete();
	
	exit();
				
	}

}
